# Dumroo.ai — AI Natural Language Query + RBAC (Assignment Submission)

This repository contains a complete solution for the Dumroo AI Developer Assignment: a small dataset and an AI-powered natural-language query system with basic role-based access control (RBAC). The project includes a Streamlit demo UI and a simple NL parser. The code is modular so it can be extended to use LangChain / real LLMs.

## Files

- `dumroo_ai_dataset.csv` — dataset (30 synthetic records). Place this file in the project root.
- `data_loader.py` — dataset loading and preprocessing utilities.
- `rbac.py` — basic role and access control logic.
- `query_processor.py` — natural language -> filter translator (heuristic + optional LLM via OpenAI/LangChain).
- `main.py` — command-line interface to ask queries.
- `streamlit_app.py` — Streamlit web UI demo.
- `requirements.txt` — Python dependencies.

## Setup

1. Create a Python 3.9+ virtual environment and activate it.

```bash
python -m venv venv
source venv/bin/activate    # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

2. Place `dumroo_ai_dataset.csv` in the project root (same folder as the .py files).

3. (Optional) If you want to enable OpenAI/LangChain parsing, set environment variable `OPENAI_API_KEY`.

```bash
export OPENAI_API_KEY="sk-..."
```

## Run CLI

```bash
python main.py
```

You will be prompted to pick an admin profile, and then you can type natural language queries like:

- `Which students haven't submitted their homework yet?`
- `Show me performance data for grade 8 from last week`
- `List all upcoming quizzes scheduled for next week`

## Run Streamlit UI

```bash
streamlit run streamlit_app.py
```

## Example queries to try
- `Which students haven't submitted their homework yet?`
- `Show students in grade 7 from North region who didn't submit homework`
- `List quizzes between 2025-01-15 and 2025-02-15`

## Notes
- The project ships with a simple rule-based NL->filter parser. If you provide an `OPENAI_API_KEY`, the code will try to use LangChain / OpenAI to parse complex queries (still limited/simple prompts included).
- RBAC is intentionally simple: an Admin object defines `grade` and `region` and only data within those scopes will be visible.
