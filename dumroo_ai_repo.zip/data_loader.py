import pandas as pd
from dateutil.parser import parse

def load_dataset(path: str = "dumroo_ai_dataset.csv") -> pd.DataFrame:
    """Load CSV and normalize columns."""
    df = pd.read_csv(path, parse_dates=["quiz_date", "submission_date"])

    # Normalize column names
    df.columns = [c.strip().lower() for c in df.columns]

    # Ensure types
    if "quiz_date" in df.columns:
        df["quiz_date"] = pd.to_datetime(df["quiz_date"])
    if "submission_date" in df.columns:
        df["submission_date"] = pd.to_datetime(df["submission_date"])

    # Add derived fields if missing
    if "homework_submitted" not in df.columns:
        df["homework_submitted"] = "Yes"

    # Create a text field for easier searching
    df["student_name_lower"] = df["student_name"].str.lower()

    return df

if __name__ == "__main__":
    df = load_dataset()
    print(df.head())
