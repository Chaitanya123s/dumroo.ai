import re
from datetime import datetime, timedelta
from dateutil.parser import parse
import pandas as pd
import os

# Optional LLM imports - used only if OPENAI_API_KEY is set
try:
    from langchain.llms import OpenAI
    from langchain import LLMChain, PromptTemplate
    LLM_AVAILABLE = True
except Exception:
    LLM_AVAILABLE = False

def parse_date_range(text: str):
    """Very small helper that tries to detect dates or relative terms.
    Returns (start_date, end_date) or (None, None) if not found.
    """
    text = text.lower()
    # Use today's date in project context
    today = datetime(2025, 11, 15)

    # relative keywords
    if "last week" in text:
        end = today - timedelta(days=today.weekday() + 1)
        start = end - timedelta(days=6)
        return start.date(), end.date()
    if "next week" in text:
        start = today + timedelta(days=(7 - today.weekday()))
        end = start + timedelta(days=6)
        return start.date(), end.date()

    # explicit date patterns
    dates = re.findall(r"\d{4}-\d{2}-\d{2}", text)
    if len(dates) == 2:
        return parse(dates[0]).date(), parse(dates[1]).date()
    if len(dates) == 1:
        d = parse(dates[0]).date()
        return d, d

    return None, None

def heuristic_parse(query: str):
    """Convert a natural language query into a dict of filters."""
    q = query.lower()
    filters = {}

    # homework submitted
    if "haven't submitted" in q or "have not submitted" in q or "not submitted" in q or "didn't submit" in q:
        filters["homework_submitted"] = "No"
    if "submitted" in q and "not" not in q and "haven't" not in q:
        filters.setdefault("homework_submitted", "Yes")

    # grade
    m = re.search(r"grade\s*(\d+)", q)
    if m:
        filters["grade"] = int(m.group(1))

    # region
    for r in ["north", "south", "east", "west", "urban", "rural"]:
        if r in q:
            filters["region"] = r.capitalize()
            break

    # class
    m = re.search(r"class\s*([abAB])", q)
    if m:
        filters["class"] = m.group(1).upper()

    # quiz date range
    start, end = parse_date_range(q)
    if start is not None:
        filters["quiz_date_range"] = (start, end)

    return filters

def apply_filters(df: pd.DataFrame, filters: dict) -> pd.DataFrame:
    out = df.copy()

    if "homework_submitted" in filters:
        out = out[out["homework_submitted"].str.lower() == filters["homework_submitted"].lower()]

    if "grade" in filters:
        out = out[out["grade"] == filters["grade"]]

    if "region" in filters:
        out = out[out["region"].str.lower() == filters["region"].lower()]

    if "class" in filters:
        out = out[out["class"].str.upper() == filters["class"].upper()]

    if "quiz_date_range" in filters:
        s, e = filters["quiz_date_range"]
        out = out[(out["quiz_date"].dt.date >= s) & (out["quiz_date"].dt.date <= e)]

    return out

def process_query(df: pd.DataFrame, query: str, admin_scope_filter=None) -> pd.DataFrame:
    """Main entry point. If OPENAI_KEY present and langchain available, tries to use LLM to parse complex queries; otherwise uses heuristics."""
    # First apply admin scope if provided
    if admin_scope_filter is not None:
        df = admin_scope_filter(df)

    # Try LLM parse if available and API key present
    if LLM_AVAILABLE and os.getenv("OPENAI_API_KEY"):
        try:
            prompt = """You are a helpful parser that receives a natural language question about student data and must output a JSON dict with fields:
- homework_submitted: "Yes"/"No" or null
- grade: integer or null
- region: string or null (North/South/East/West)
- class: string or null
- quiz_date_range: ["YYYY-MM-DD", "YYYY-MM-DD"] or null
Only return the JSON object.
Question: {query}
""".format(query=query)

            template = PromptTemplate(input_variables=["query"], template=prompt)
            llm = OpenAI(temperature=0)
            chain = LLMChain(llm=llm, prompt=template)
            res = chain.run(query=query)
            import json
            parsed = json.loads(res)
            filters = {}
            if parsed.get("homework_submitted"):
                filters["homework_submitted"] = parsed["homework_submitted"]
            if parsed.get("grade"):
                filters["grade"] = int(parsed["grade"])
            if parsed.get("region"):
                filters["region"] = parsed["region"]
            if parsed.get("class"):
                filters["class"] = parsed["class"]
            if parsed.get("quiz_date_range"):
                s, e = parsed["quiz_date_range"]
                filters["quiz_date_range"] = (parse(s).date(), parse(e).date())

            return apply_filters(df, filters)
        except Exception:
            # fallback
            pass

    # Fallback to heuristic parse
    filters = heuristic_parse(query)
    return apply_filters(df, filters)
