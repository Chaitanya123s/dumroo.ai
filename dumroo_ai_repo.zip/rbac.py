from dataclasses import dataclass

@dataclass
class Admin:
    name: str
    grade: int = None
    region: str = None
    class_section: str = None

def scope_filter(df, admin: Admin):
    """Return a filtered dataframe according to admin's scope."""
    out = df.copy()

    if admin.grade is not None:
        out = out[out["grade"] == admin.grade]
    if admin.region is not None:
        out = out[out["region"].str.lower() == admin.region.lower()]
    if admin.class_section is not None:
        out = out[out["class"].str.upper() == admin.class_section.upper()]

    return out
