from data_loader import load_dataset
from rbac import Admin, scope_filter
from query_processor import process_query

def select_admin_profile():
    # Provide a few demo admin profiles
    profiles = [
        Admin(name="Ramesh", grade=8, region="North"),
        Admin(name="Sana", grade=7, region="South"),
        Admin(name="Amit", grade=None, region="East"),
    ]

    print("Available admin profiles:")
    for i, p in enumerate(profiles, 1):
        print(f"{i}. {p.name} — grade={p.grade} region={p.region}")

    idx = int(input("Select admin (number): ")) - 1
    return profiles[idx]

def main():
    df = load_dataset()
    admin = select_admin_profile()

    def admin_scope(dframe):
        return scope_filter(dframe, admin)

    print(f"Logged in as admin: {admin.name} (grade={admin.grade}, region={admin.region})")

    while True:
        q = input("Enter natural language query (or 'exit'): ")
        if q.strip().lower() in ("exit", "quit"):
            break
        res = process_query(df, q, admin_scope_filter=admin_scope)
        if res.empty:
            print("No results — either no matching rows or access denied by RBAC.")
        else:
            print(res.to_string(index=False))

if __name__ == "__main__":
    main()
