import streamlit as st
from data_loader import load_dataset
from rbac import Admin, scope_filter
from query_processor import process_query

st.set_page_config(page_title="Dumroo AI — NLQ Demo", layout="wide")

st.title("Dumroo.ai — Natural Language Query (NLQ) + RBAC Demo")

# Load data
@st.cache_data
def get_data():
    return load_dataset()

df = get_data()

# Demo admin selection
st.sidebar.header("Admin Login (demo)")
admin_name = st.sidebar.selectbox("Select admin", ["Ramesh", "Sana", "Amit"])
if admin_name == "Ramesh":
    admin = Admin(name="Ramesh", grade=8, region="North")
elif admin_name == "Sana":
    admin = Admin(name="Sana", grade=7, region="South")
else:
    admin = Admin(name="Amit", grade=None, region="East")

st.sidebar.write(f"Logged in as: {admin.name} — grade={admin.grade}, region={admin.region}")

query = st.text_input("Enter natural language query", value="Which students haven't submitted their homework yet?")

if st.button("Run Query"):
    def admin_scope(dframe):
        return scope_filter(dframe, admin)

    res = process_query(df, query, admin_scope_filter=admin_scope)

    if res.empty:
        st.warning("No results — either no matching rows or access restricted by RBAC.")
    else:
        st.dataframe(res)
        st.download_button("Download results as CSV", res.to_csv(index=False), file_name="query_results.csv")

st.markdown("---")
st.markdown("**Dataset preview**")
st.dataframe(df)
